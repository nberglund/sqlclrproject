Imports System
Imports System.Data
Imports System.Data.Sql
Imports System.Data.SqlTypes
Imports System.Data.SqlClient
Imports Microsoft.SqlServer.Server
Imports DM.Build.Yukon.Attributes

Public Class $safeitemrootname$

  'Skeleton Code for Procedures/Functions/Triggers

  '<SqlProcedure()> _
  'Public Shared Sub ProcedureName()

  'End Sub

  '<SqlFunction()> _
  'Public Shared Function FunctionName() As SqlInt32
  '  Return 0
  'End Function

  '<SqlTrigger(Target:="TblName", Event:="FOR INSERT")> _
  'Public Shared Sub TriggerName()

  'End Sub



End Class

