using System;
using System.Data;
using System.Data.Sql;
using System.Data.SqlTypes;
using System.Data.SqlClient;
using Microsoft.SqlServer.Server;
using DM.Build.Yukon.Attributes;

public class $safeitemrootname$ {
  
  //Skeleton methods - fill in your code
  //[SqlProcedure]
  //public static void ProcedureName() {
  
  //}

  //[SqlFunction]
  //public static SqlInt32 FunctionName() {
    
  //  return 0;
  //}

  //[SqlTrigger(Target="TblName", Event="FOR INSERT")]
  //public static void TriggerName() {

  //}

}

